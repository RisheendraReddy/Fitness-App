import SwiftUI

struct ActivityRingView: View {
    let progress: CGFloat  // Value between 0 and 1
    let ringColor: Color
    let ringWidth: CGFloat

    var body: some View {
        ZStack {
            Circle()
                .stroke(ringColor.opacity(0.3), lineWidth: ringWidth) // Background ring
            
            Circle()
                .trim(from: 0, to: progress) // Trimmed to progress
                .stroke(ringColor, style: StrokeStyle(lineWidth: ringWidth, lineCap: .round))
                .rotationEffect(.degrees(-90)) // Start from top
                .animation(.easeOut(duration: 1.5), value: progress)
        }
    }
}

struct FitnessActivityRingsView: View {
    let caloriesBurned: CGFloat = 0.8
    let exerciseMinutes: CGFloat = 0.6
    let stepsTaken: CGFloat = 0.9

    var body: some View {
        ZStack {
            // Full-screen gradient background
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.black]), startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 30) {
                Text("Daily Activity")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    .padding(.top, 50)

                ZStack {
                    ActivityRingView(progress: caloriesBurned, ringColor: .red, ringWidth: 16)
                        .frame(width: 200, height: 200)

                    ActivityRingView(progress: exerciseMinutes, ringColor: .green, ringWidth: 12)
                        .frame(width: 160, height: 160)

                    ActivityRingView(progress: stepsTaken, ringColor: .blue, ringWidth: 10)
                        .frame(width: 120, height: 120)

                    VStack {
                        Text("🔥 💪 🚶‍♂️")
                            .font(.title)
                            .foregroundColor(.white)
                        Text("Keep Moving!")
                            .font(.headline)
                            .foregroundColor(.white.opacity(0.8))
                    }
                }

                Spacer()
            }
        }
    }
}

struct ActivityRingView_Previews: PreviewProvider {
    static var previews: some View {
        FitnessActivityRingsView()
    }
}
