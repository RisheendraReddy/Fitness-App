//
//  WorkoutVM.swift
//  FitnessApp1
//
//  Created by Chris Pekin on 3/24/25.
//
import SwiftUI
import Foundation
import FirebaseFirestore
import FirebaseAuth
//
//class WorkoutViewModel: ObservableObject {
//    @Published var workouts: [Workout] = []
//    
//    func logWorkout(workout: Workout) {
//        workouts.append(workout)
//    }
//}




class WorkoutVM: ObservableObject {
  
    @Published var workouts: [Workout] = []
  
    //initialize the DB
    private let firestoreService = FirestoreService()
//old
//    init()
//    {
//        
//        //Bring forth and get exisiting saved workouts in the DB when the app loads up and VM is initialized
//        fetchWorkouts()
//    }
  
    //thurdsday 2pm
//    init() {
//        // load on startup
//        loadMyWorkouts()
//        // reload whenever auth state changes
//        Auth.auth().addStateDidChangeListener { _, user in
//            if user != nil {
//                self.loadMyWorkouts()
//            } else {
//                self.workouts = []
//            }
//        }
//    }
    //thursday 4pm
    init() {
           // reload whenever auth state changes
           Auth.auth().addStateDidChangeListener { _, _ in
               self.loadMyWorkouts()
           }
       }
   

//old
//Need to differentiate workout saving from activity saving-one will be for you to save your lifts with sets and reps
   
//    func logWorkout(type: String, duration: Int, caloriesBurned: Int)
//    {
//        //create and save a new workout below
//        let newWorkout = Workout(type: type, duration: duration, caloriesBurned: caloriesBurned, date: Date())
//
//        //Commit a workout/"activity" to the DB via saveworkout fxn
//        firestoreService.saveWorkout(workout: newWorkout)
//        {
//            
//            success in
//            if success {
//                //// Refresh the workout list after saving
//                self.fetchWorkouts()
//            }
//        }
//    }
    
//new
    
    func logWorkout(type: String, duration: Int, caloriesBurned: Int)
    {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        let w = Workout(
          userId:         uid,
          type:           type,
          duration:       duration,
          caloriesBurned: caloriesBurned,
          date:           Date()
        )
        firestoreService.saveWorkout(w) { success in
            if success { self.loadMyWorkouts() }
        }
    }
    

    

    
//old1
//function to get the workouts from the database, bring forward workouts in fetched workouts
//    func fetchWorkouts()
//    {
//        firestoreService.fetchWorkouts{
//            
//            fetchedWorkouts in
//            self.workouts = fetchedWorkouts
//        }
//    }
    
    //old2
//    func loadMyWorkouts() {
//        guard let uid = Auth.auth().currentUser?.uid else {
//            workouts = []
//            return
//        }
//        firestoreService.fetchWorkouts(for: uid) { fetched in
//            DispatchQueue.main.async { self.workouts = fetched }
//        }
//    }
    //thursday 1pm
    func loadMyWorkouts() {
      guard let uid = Auth.auth().currentUser?.uid else {
        DispatchQueue.main.async { self.workouts = [] }
        return
      }
        firestoreService.fetchWorkouts(for: uid) { fetched in
        DispatchQueue.main.async {
          self.workouts = fetched
        }
      }
    }
    
    
   

}

//#Preview {
//    WorkoutVM()
//}


