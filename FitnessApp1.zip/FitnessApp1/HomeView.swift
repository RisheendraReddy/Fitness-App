//
//  HomeView.swift
//  FitnessApp1
//
//  Created by Chris Pekin on 3/24/25.
//

import SwiftUI
//change name to activity log since this is what it is --not a home view originally was
struct HomeView: View {
    
    //@ObservedObject var workoutVM = WorkoutVM()
    @ObservedObject var workoutVM: WorkoutVM
    var body: some View {
        NavigationView {
            ZStack {
                //Main Background gradient
                LinearGradient(
                    gradient: Gradient(colors: [Color.black, Color.blue.opacity(0.8)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .edgesIgnoringSafeArea(.all)//expand
                
                VStack(spacing: 20) {
                    //Page Title
                    Text("Workout Tracker")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.white)
                        .padding(.top, 40)
                    
                    //How the activity cards are dipslayed as log items--use workout VM and M
                    ScrollView {
                        VStack(spacing: 15) {
                            ForEach(workoutVM.workouts) { workout in
                                WorkoutCard(workout: workout)
                            }
                        }
                        .padding(.horizontal, 20)
                    }
                }
            }
            .navigationBarHidden(true)
            //playing around with visibility of nav bar
        }.onAppear {
            workoutVM.loadMyWorkouts()               // reload on view appear
        }
    }
    
    //Logic for each activity card
    struct WorkoutCard: View {
        let workout: Workout
        
        var body: some View {
            HStack {
                
                
                //add date and time?????
                VStack(alignment: .leading, spacing: 5) {
                    
                    
                    Text(workout.type)
                        .font(.title2)
                        .bold()
                        .foregroundColor(.white)
                    
                    
                    Text("Duration: \(workout.duration) mins")
                        .font(.body)
                        .foregroundColor(.white.opacity(0.8))
                    
                    
                    
                    Text("Calories: \(workout.caloriesBurned)")
                        .font(.body)
                        .foregroundColor(.white.opacity(0.8))
                }
                
                Spacer()
                
                // !!!!!!!//ADD MORE ICONS --only the walker rn!!!!!!!!!!!!
                //            Image(systemName: "figure.walk")
                //                .foregroundColor(.white)
                //                .font(.system(size: 30))
                //                .padding()
                
                //account for differnet activity types via differnt icons and key words
                
                //WORK ON TEXT COLOR DIFFERENTATION --cals--see figma
                if(workout.type.starts(with: "Lift"))
                {
                    Image(systemName: "dumbbell.fill")
                        .foregroundColor(.white)
                        .font(.system(size: 30))
                        .padding()
                }
                if(workout.type.starts(with: "Run") || workout.type.starts(with: "Sprints") || workout.type.starts(with: "Jog") ||  workout.type.starts(with: "Walk"))
                {
                    Image(systemName: "figure.walk")
                        .foregroundColor(.white)
                        .font(.system(size: 30))
                        .padding()
                }
                if(workout.type.starts(with: "Sleep"))
                {
                    Image(systemName: "bed.double.fill")
                        .foregroundColor(.white)
                        .font(.system(size: 30))
                        .padding()
                }
                if(workout.type.starts(with: "Cycling") || workout.type.starts(with: "Biking") || workout.type.starts(with: "Bike")){
                    Image(systemName: "figure.outdoor.cycle")
                        .foregroundColor(.white)
                        .font(.system(size: 30))
                        .padding()
                }
                if(workout.type.starts(with: "Swim") ||  workout.type.starts(with: "Swimming"))
                {
                    Image(systemName: "figure.open.water.swim")
                        .foregroundColor(.white)
                        .font(.system(size: 30))
                        .padding()
                }
            }
            .padding()
            .background(Color.white.opacity(0.15))
            .cornerRadius(15)
            .shadow(color: .black.opacity(0.3), radius: 5, x: 0, y: 5)
        }
    }
    
}
//
//#Preview {
//    HomeView()
//}
