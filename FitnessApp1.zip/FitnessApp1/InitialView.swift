//
//  InitialView.swift
//  FitnessApp1
//
//  Created by Chris Pekin on 4/17/25.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth
//thurday 2pm
/*
struct InitialView: View {
    @State private var userLoggedIn = (Auth.auth().currentUser != nil)
       
       
       var body: some View {
           VStack{
               if userLoggedIn{
                   MainTabView()
               } else {
                   //signin here next instea
                   LoginView()
               }
               
               
           }.onAppear{
               
               Auth.auth().addStateDidChangeListener{auth, user in
               
                   if (user != nil) {
                       
                       userLoggedIn = true
                   } else{
                       userLoggedIn = false
                   }
               }
           }
       }
}
*/

//#Preview {
//    InitialView()
//}
//thursday 5pm
struct InitialView: View {
    @EnvironmentObject var authVM: AuthenticationView
    @State private var userLoggedIn = Auth.auth().currentUser != nil

    var body: some View {
        Group {
            if userLoggedIn || authVM.isLoginSuccessed {
                MainTabView()
            } else {
                LoginView()
            }
        }
        .onAppear {
            // seed initial state
            userLoggedIn = Auth.auth().currentUser != nil

            // listen for any auth changes (email/password or Google)
            Auth.auth().addStateDidChangeListener { _, user in
                userLoggedIn = (user != nil)
            }
        }
    }
}

#Preview {
    LoginView()
      .environmentObject(AuthenticationView())
}

