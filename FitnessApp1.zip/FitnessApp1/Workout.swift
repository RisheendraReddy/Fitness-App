import Foundation
import SwiftUI

//base workkout file -model
//struct Workout: Identifiable, Codable {
//    let id: UUID = UUID()
//    let type: String
//    let duration: Int // in minutes
//    let caloriesBurned: Int
//    let date: Date
//}

//import FirebaseFirestoreSwift
import FirebaseFirestore
struct Workout: Identifiable, Codable {
    @DocumentID var id: String?       // now Xcode recognizes this
    let userId: String
    let type: String
    let duration: Int
    let caloriesBurned: Int
    let date: Date
}
