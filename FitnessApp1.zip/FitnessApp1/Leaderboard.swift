import SwiftUI

struct LeaderboardEntry: Identifiable {
    let id = UUID()
    let username: String
    let totalCaloriesBurned: Int
    let profileImage: String
}

struct LeaderboardView: View {
    
    //mock leaerboard data--expand functionality
    let leaderboardData = [
        LeaderboardEntry(username: "Chris", totalCaloriesBurned: 3000, profileImage: "profile1"),
        LeaderboardEntry(username: "Rishi", totalCaloriesBurned: 2500, profileImage: "profile2"),
        LeaderboardEntry(username: "Alex", totalCaloriesBurned: 2200, profileImage: "profile3"),
        LeaderboardEntry(username: "Jamie", totalCaloriesBurned: 1900, profileImage: "profile4"),
        LeaderboardEntry(username: "Sam", totalCaloriesBurned: 1800, profileImage: "profile5")
    ]

    var body: some View {
        ZStack {
         
            LinearGradient(gradient: Gradient(colors: [Color.black, Color.blue.opacity(0.8)]),
                           startPoint: .top, endPoint: .bottom)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                
                Text("Leaderboard")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(.white)
                    .padding(.top, 40)
                //modify to show at idfferent heights
                HStack {
                    ForEach(leaderboardData.prefix(3).indices, id: \.self)
                    {
                        index in TopThreeView(entry: leaderboardData[index], rank: index + 1)
                    }
                }
                .padding(.vertical)
                
                ScrollView {
                    VStack(spacing: 15) {
                        ForEach(leaderboardData.dropFirst(0))
                        {
                            entry in LeaderboardRow(entry: entry)
                        }
                    }
                    .padding()
                }
            }
        }
    }
}

struct TopThreeView: View {
    
    
    let entry: LeaderboardEntry
    let rank: Int
    
    var body: some View {
        VStack {
            Image(entry.profileImage)
                .resizable()
                .scaledToFill()
                .frame(width: 80, height: 80)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white, lineWidth: 3))
                .shadow(radius: 5)
            
            Text(entry.username)
                .font(.headline)
                .foregroundColor(.white)
            //adjust colors
            //green?
        
            Text("\(entry.totalCaloriesBurned) Cal")
                .font(.title3)
                .bold()
                .foregroundColor(rank == 1 ? .yellow : .white)
        }
        .padding()
    }
}

//each user row on the leaderboard
struct LeaderboardRow: View {
    let entry: LeaderboardEntry
    
    var body: some View {
        HStack {
            //load avatars images etc...
            Image(entry.profileImage)
                .resizable()
                .scaledToFill()
                .frame(width: 50, height: 50)
                .clipShape(Circle())

            VStack(alignment: .leading) {
              
                Text(entry.username)
                    .font(.headline)
                    .foregroundColor(.white)
              
                Text("\(entry.totalCaloriesBurned) Calories Burned")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            Text("\(entry.totalCaloriesBurned)")
                .font(.headline)
                .bold()
                .foregroundColor(.green)
        }
        .padding()
        .background(Color.blue.opacity(0.3))
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .shadow(radius: 3)
    }
}

#Preview {
    LeaderboardView()
}
