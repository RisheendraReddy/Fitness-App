//
//  FitnessApp1App.swift
//  FitnessApp1
//
//  Created by Chris Pekin on 3/20/25.
//


//
//@main
//struct WorkoutApp: App {
//    init() {
//        FirebaseApp.configure()
//    }
//
//    var body: some Scene {
//        WindowGroup {
//            MainTabView()
//        }
//    }
//}
import SwiftUI
import SwiftUI
import FirebaseCore
import FirebaseFirestore
import Firebase
import GoogleSignIn
//provided in documentation for firebase
//link for database
//set starting point
//original app delegate



//class AppDelegate: NSObject, UIApplicationDelegate {
//  func application(_ application: UIApplication,
//                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
//    FirebaseApp.configure()
//      let db = Firestore.firestore()
//
//    return true
//  }
//}

//mAIN
@main
struct WorkoutApp: App {
    
    //delegate necssary for db
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate

        @StateObject var authVM = AuthenticationView()
    var body: some Scene {
        WindowGroup {
            InitialView()
                .environmentObject(authVM)
            //MainTabView()//app start point
          
            
            // ContentView()
            // ActivityRingView()
        }
    }
}

//new app delegate
class AppDelegate: NSObject, UIApplicationDelegate
{
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool{
        FirebaseApp.configure()
        return true
    }
    
    @available(iOS 9.0, *)
    
    func application(_ application: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        return GIDSignIn.sharedInstance.handle(url)
    }
}
