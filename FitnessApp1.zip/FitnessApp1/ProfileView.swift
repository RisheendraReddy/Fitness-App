import SwiftUI
import FirebaseAuth

struct ProfileView: View {
    @State private var err: String = ""
    @State private var userName: String = "" // manual name entry fallback

    // Compute the display name based on Google login, manual entry, or email prefix
    private var displayName: String {
        let firebaseUser = Auth.auth().currentUser
        if let name = firebaseUser?.displayName, !name.isEmpty {
            return name
        } else if !userName.isEmpty {
            return userName
        } else if let email = firebaseUser?.email {
            return String(email.split(separator: "@")[0])
        } else {
            return "User"
        }
    }

    var body: some View {
        NavigationView {
            ZStack {
                // Gradient background matching the rest of the app
                LinearGradient(
                    gradient: Gradient(colors: [Color.black, Color.blue.opacity(0.8)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .edgesIgnoringSafeArea(.all)

                VStack(spacing: 16) {
                    // Top bar
                    HStack {
                        Button(action: { /* go back */ }) {
                            Image(systemName: "chevron.left")
                                .font(.title2)
                                .foregroundColor(.white)
                        }
                        Spacer()
                        Image(systemName: "iphone.homebutton")
                            .font(.title2)
                            .foregroundColor(.white)
                        Spacer()
                        Button(action: { /* open menu */ }) {
                            Image(systemName: "line.horizontal.3")
                                .font(.title2)
                                .foregroundColor(.white)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.top, 8)

                    // Profile header
                    HStack(alignment: .center, spacing: 12) {
                        Image("profilePic")
                            .resizable()
                            .frame(width: 60, height: 60)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.white, lineWidth: 2))

                        VStack(alignment: .leading, spacing: 4) {
                            Text(displayName)
                                .font(.title)
                                .bold()
                                .foregroundColor(.white)
                            Text("Gold Member")
                                .font(.subheadline)
                                .foregroundColor(.white.opacity(0.8))
                        }
                        Spacer()
                    }
                    .padding(.horizontal)

                    // Content
                    ScrollView(showsIndicators: false) {
                        VStack(alignment: .leading, spacing: 24) {
                            // Stats
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Your Stats")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                HStack(spacing: 12) {
                                    StatCard(title: "Workouts", value: "24")
                                    StatCard(title: "Calories", value: "3.4K")
                                    StatCard(title: "Rank", value: "#1")
                                }
                            }

                            // Badges
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Badges")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 16) {
                                        BadgeView(imageName: "badge1")
                                        BadgeView(imageName: "badge2")
                                        BadgeView(imageName: "badge3")
                                    }
                                }
                            }

                            // Settings & Actions
                            VStack(spacing: 1) {
                                ProfileRow(icon: "gearshape", title: "Settings")
                                ProfileRow(icon: "bell", title: "Notifications")
                                ProfileRow(icon: "questionmark.circle", title: "Help & Support")

                                Button(action: {
                                    Task {
                                        do {
                                            try await AuthenticationView().logout()
                                        } catch {
                                            err = error.localizedDescription
                                        }
                                    }
                                }) {
                                    Text("Log Out")
                                        .foregroundColor(.white)
                                        .padding(8)
                                        .frame(maxWidth: .infinity)
                                        .background(Color.red)
                                        .cornerRadius(8)
                                }

                                if !err.isEmpty {
                                    Text(err)
                                        .foregroundColor(.red)
                                        .font(.caption)
                                }
                            }
                            .background(Color.white.opacity(0.1))
                            .cornerRadius(10)
                        }
                        .padding(.horizontal)
                    }
                    Spacer()
                }
            }
            .navigationBarHidden(true)
        }
    }
}

// MARK: - Helper Views - StatCard, BadgeView, ProfileRow

struct StatCard: View {
    let title: String
    let value: String

    var body: some View {
        VStack {
            Text(value)
                .font(.title2)
                .bold()
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.tertiarySystemBackground))
        .cornerRadius(12)
    }
}

struct BadgeView: View {
    let imageName: String

    var body: some View {
        Image(imageName)
            .resizable()
            .frame(width: 60, height: 60)
            .padding(8)
            .background(Color(.systemBackground))
            .cornerRadius(8)
            .shadow(radius: 2)
    }
}

struct ProfileRow: View {
    let icon: String
    let title: String

    var body: some View {
        HStack {
            Image(systemName: icon)
                .frame(width: 24)
                .foregroundColor(.white)
            Text(title)
                .foregroundColor(.white)
            Spacer()
            Image(systemName: "chevron.right")
                .foregroundColor(.secondary)
        }
        .padding()
        .background(Color(.systemBackground))
    }
}
#Preview {
    ProfileView()
}
