//
//  MainTab.swift
//  FitnessApp1
//
//  Created by Chris Pekin on 3/24/25.
//

//current main tab----will have to change eventually 

import SwiftUI
//
//struct MainTabView: View {
//    @StateObject var workoutView = WorkoutVM()
//
//    init() {
//       UITabBar.appearance().barTintColor = UIColor.black // Ensure black tab bar
//      // UITabBar.appearance().unselectedItemTintColor = UIColor.white // Set unselected tab icons to white
//    }
//
//    var body: some View {
//        TabView {
//            HomeView(workoutVM: workoutView)
//                .tabItem {
//                    Image(systemName: "house.fill")
//                        .renderingMode(.template) // Ensures it adopts foreground color
//                    Text("Home")
//                }
//
//            WorkoutLoggingView(workoutVM: workoutView)
//                .tabItem {
//                    Image(systemName: "plus.circle.fill")
//                        .renderingMode(.template)
//                    Text("Log Workout")
//                }
//
//            LeaderboardView()
//                .tabItem {
//                    Image(systemName: "chart.bar.fill")
//                        .renderingMode(.template)
//                    Text("Leaderboard")
//                }
//        }
//        .accentColor(.white) // Makes selected tab icon white
//        .background(Color.black.edgesIgnoringSafeArea(.all)) // Ensures full black background
//    }
//}
//
struct MainTabView: View {
    @StateObject var workoutVM = WorkoutVM()

    var body: some View {
       //BOTTOM TOOLBAR LOGIC
        TabView {
            
            HomeView(workoutVM: workoutVM) //pass HomeView vm
                .tabItem {
                    Image(systemName: "house.fill")
                        .renderingMode(.template)
                    Text("Home")
                } //Need different things happening on home oage---see figma
//            ActivityRingView(progress: CGFloat, ringColor: Color, ringWidth: CGFloat)
//                .tabItem {
//                    Image(systemName: "house.fill")
//                        .renderingMode(.template)
//                    Text("Home")
//                }
//convert this to axtivity log
           
            WorkoutLoggingView(workoutVM: workoutVM)
            // Pass workoutVM here as well
                .tabItem {
                    Image(systemName: "plus.circle.fill")
                        .renderingMode(.template)
                    Text("Log Workout")//-----> "Activity Log"
                }
            //Evolve it to where its an activity log where they log their activity or more specific workout tracking via different buttons within the tab
          
            ExerciseListView()
                   .tabItem {
                       Image(systemName: "list.bullet")
                           .renderingMode(.template)
                       Text("Exercises")
                   }
            
            LeaderboardView()
                .tabItem {
                    Image(systemName: "chart.bar.fill")
                        .renderingMode(.template)
                    Text("Leaderboard")
                }
            ProfileView()
                .tabItem {
                    Image(systemName: "person.circle.fill")
                        .renderingMode(.template)
                    Text("Profile")
                }
//            ProfileView()
//                .tabItem {
//                    Image(systemName: "person.crop.circle")
//                       
//                   
//                       
//                    Text("Profile")
//                }
            
            
            //1!!!!!!!!!!!!ADD A TAB FOR HOME AND MY PROFILE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        }
        .accentColor(.white) //change color of selected icon
        .background(Color.black.edgesIgnoringSafeArea(.all))
    }
}


#Preview {
    MainTabView()
}
